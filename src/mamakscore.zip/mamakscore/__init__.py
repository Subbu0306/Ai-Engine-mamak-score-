"""MamakScore AI Engine."""

__version__ = "0.1.0"
